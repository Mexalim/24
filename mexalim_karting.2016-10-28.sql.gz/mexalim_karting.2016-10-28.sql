
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `pilots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pilots` (
  `pilot_id` int(10) NOT NULL,
  `team_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `time_in_race` time NOT NULL,
  `time_start` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `pitstops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pitstops` (
  `kart_number` int(10) NOT NULL,
  `team_id` int(10) NOT NULL,
  `pilot_id` int(10) NOT NULL,
  `time_to_pit` datetime NOT NULL,
  `pits_num` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `race_time` time NOT NULL,
  `part_time_race` time NOT NULL,
  `kart_number` int(11) NOT NULL,
  `lap_pit_number` int(11) NOT NULL,
  `team_number` int(11) NOT NULL,
  `pilot_number` int(11) NOT NULL,
  `number_pit` int(11) NOT NULL,
  `pilot_in_race` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `name_setting` text NOT NULL,
  `value_setting` text NOT NULL,
  `value_setting_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `number` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `timing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timing` (
  `transponder_id` varchar(11) NOT NULL,
  `get_time` varchar(11) NOT NULL,
  `last_lap` varchar(11) NOT NULL,
  `lsat_2_lap` varchar(11) NOT NULL,
  `best_lap` varchar(11) NOT NULL,
  `real_kart_number` varchar(11) NOT NULL,
  `wather` text NOT NULL,
  `pilot_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `lost_time` datetime NOT NULL,
  `transponder_time` varchar(11) NOT NULL,
  `track_konfig` int(11) NOT NULL,
  `laps` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `timing_hostory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timing_hostory` (
  `transponder_id` varchar(11) NOT NULL,
  `get_time` varchar(11) NOT NULL,
  `last_lap` varchar(11) NOT NULL,
  `lsat_2_lap` varchar(11) NOT NULL,
  `best_lap` varchar(11) NOT NULL,
  `real_kart_number` varchar(11) NOT NULL,
  `wather` text NOT NULL,
  `pilot_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `lost_time` datetime NOT NULL,
  `transponder_time` varchar(11) NOT NULL,
  `track_konfig` int(11) NOT NULL,
  `laps` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

LOCK TABLES `pilots` WRITE;
/*!40000 ALTER TABLE `pilots` DISABLE KEYS */;
/*!40000 ALTER TABLE `pilots` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `pitstops` WRITE;
/*!40000 ALTER TABLE `pitstops` DISABLE KEYS */;
/*!40000 ALTER TABLE `pitstops` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('wether','dry','0000-00-00 00:00:00'),('konfig_id','2','0000-00-00 00:00:00'),('time_race','2016-10-25 15:19:59','0000-00-00 00:00:00'),('fromid','9881','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `timing` WRITE;
/*!40000 ALTER TABLE `timing` DISABLE KEYS */;
INSERT INTO `timing` VALUES ('2261324','1477687963','40.825','40.857','39.542','13','dry',0,0,'0000-00-00 00:00:00','0',1,'140'),('2744699','1477690331','44.892','43.566','39.730','9','dry',0,0,'0000-00-00 00:00:00','0',1,'239'),('2758575','1477686144','40.389','40.025','39.998','69','dry',0,0,'0000-00-00 00:00:00','0',1,'253'),('2807865','1477691402','42.386','41.529','39.247','33','dry',0,0,'0000-00-00 00:00:00','0',1,'243'),('4010917','1477689427','41.086','40.982','39.841','5','dry',0,0,'0000-00-00 00:00:00','0',1,'357'),('4078493','1477691383','40.536','41.179','39.831','21','dry',0,0,'0000-00-00 00:00:00','0',1,'190'),('4684020','1477689454','41.283','40.927','39.704','8','dry',0,0,'0000-00-00 00:00:00','0',1,'213'),('4981252','1477691380','41.210','40.893','39.785','10','dry',0,0,'0000-00-00 00:00:00','0',1,'245'),('5901907','1477691403','42.621','40.486','40.486','4','dry',0,0,'0000-00-00 00:00:00','0',1,'216'),('5927164','1477691374','44.178','44.621','40.485','7','dry',0,0,'0000-00-00 00:00:00','0',1,'197'),('5957013','1477691401','86.925','41.591','39.705','3','dry',0,0,'0000-00-00 00:00:00','0',1,'204'),('7181239','1477691359','45.772','44.863','40.149','2','dry',0,0,'0000-00-00 00:00:00','0',1,'213'),('9614994','1477689444','41.062','40.870','39.728','6','dry',0,0,'0000-00-00 00:00:00','0',1,'243'),('9661676','1477691359','43.648','43.794','39.745','1','dry',0,0,'0000-00-00 00:00:00','0',1,'119');
/*!40000 ALTER TABLE `timing` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `timing_hostory` WRITE;
/*!40000 ALTER TABLE `timing_hostory` DISABLE KEYS */;
INSERT INTO `timing_hostory` VALUES ('4010917','','39.841','','39.841','5','',0,0,'0000-00-00 00:00:00','',0,'328'),('2261324','','39.542','','39.542','13','',0,2,'0000-00-00 00:00:00','',0,'125'),('4010917','','39.841','','39.841','5','',0,0,'0000-00-00 00:00:00','',0,'328'),('2261324','','39.542','','39.542','13','',0,0,'0000-00-00 00:00:00','',0,'125'),('4010917','','39.841','','39.841','5','',0,0,'0000-00-00 00:00:00','',0,'328'),('4010917','','39.841','','39.841','5','',0,0,'0000-00-00 00:00:00','',0,'328'),('5901907','','40.868','','40.786','4','',0,0,'0000-00-00 00:00:00','',0,'208'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.535','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'209'),('5901907','','40.590','','40.535','4','',0,0,'0000-00-00 00:00:00','',0,'213'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.528','','40.528','4','',0,0,'0000-00-00 00:00:00','',0,'214'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215'),('5901907','','40.486','','40.486','4','',0,0,'0000-00-00 00:00:00','',0,'215');
/*!40000 ALTER TABLE `timing_hostory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

